import java.util.Scanner;
public class soalCp2 {
    public static boolean prima(int n){
        if ( n <= 1){
        return false;
        }
        for(int i = 2; i <= Math.sqrt(n); i++){
            if(n % i == 0){
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan bilangan bulat: ");
        int n = input.nextInt();
        if(prima(n)){
            System.out.println(n + " adalah bilangan prima");
        } else {
            System.out.println(n + " bukan bilangan prima");
        }
        input.close();
    }
}
